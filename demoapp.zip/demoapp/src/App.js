import './App.css';
import { useState } from 'react';
import Counter from './components/Counter';
// import AddNumber from './components/AddNumber';
// import Profile from './components/Profile';

function App() {
  const [num1, setNum1] = useState('');
  const [num2, setNum2] = useState('');

  function handleChangeNum1(e) {
      setNum1(e.target.value);
  }

  return (
    <div className="container">
      {/* <h1>Hi There!!</h1> */}
      {/* <div>
        <label >First Number: </label>
        <input type="number" id='num1' onChange={handleChangeNum1}
        className="form-control"/>
        <br></br>
        <label>Second Number: </label>
        <input type='number' onChange={(e) => setNum2(e.target.value)}
        className="form-control"/>
        <br/>
      </div>

      <AddNumber num1={num1} num2={num2}/> */}

      {/* <Profile title='Pallavi' desig='Trainer'/>
      <Profile title='Prithvi' desig='Developer'/> */}

        <Counter />
    </div>
  );
}

export default App;
