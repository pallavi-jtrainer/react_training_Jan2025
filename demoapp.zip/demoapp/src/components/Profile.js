
export default function Profile({title, desig}) {
    let name = title;
    let designation = desig;

    return (<div>
        {/* <h2>Name: {props.title}</h2>
        <h2>Desgination: {props.desig}</h2> */}

        <h3>Name: {name}</h3>
        <h3>Desgination: {designation}</h3>
    </div>)
}