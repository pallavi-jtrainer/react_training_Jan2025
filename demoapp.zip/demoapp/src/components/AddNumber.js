import { useState } from "react";

export default function AddNumber(props) {
    // const [num1, setNum1] = useState('');
    // const [num2, setNum2] = useState('');
    // const [result, setResult] = useState();

    function handleClick() {
        alert(Number(props.num1) + Number(props.num2));
    }

    // function handleChangeNum1(e) {
    //     setNum1(e.target.value);
    // }

    return(
        <div>
        {/* <label>First Number: </label>
        <input type="number" id='num1' onChange={handleChangeNum1}/>
        <br></br>
        <label>Second Number: </label>
        <input type='number' onChange={(e) => setNum2(e.target.value)}/>
        <br/>
        <label>Result: </label>
        <input type='text' value={result}/>
        <br/>

        <br/> */}
        <button className="btn btn-success" onClick={handleClick}>Add</button>
      </div>
    );
}