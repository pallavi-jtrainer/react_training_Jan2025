//1. import react and react-dom libraries
import React from 'react';
import ReactDOM from 'react-dom/client';

//2. create the root element
const el = document.getElementById("root");
const root = ReactDOM.createRoot(el);

//3. create the component
function App() {
    let name = "Prithvi";

    return (<div>
        <h1> Welcome to React, {name}</h1>
    </div>
    )
}

//4. render the component
root.render(<App/>);
//5. run the application