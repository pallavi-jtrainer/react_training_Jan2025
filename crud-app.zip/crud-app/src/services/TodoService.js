import HttpCommon from "./HttpCommon";

export const getAllTodos = () => {
    return HttpCommon.get("/todos");
}

export const getTodo = (id) => {
    return HttpCommon.get(`/todos/${id}`);
}

export const createTodo = (data) => {
    return HttpCommon.post("/todos", data);
}

export const updateTodo = (id, data) => {
    return HttpCommon.put(`/todos/${id}`, data);
}

export const deleteTodo = (id) => {
    return HttpCommon.delete(`/todos/${id}`);
}