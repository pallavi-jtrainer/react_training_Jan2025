// import axios from "axios";
import { useEffect, useState } from "react";
// import Edittodo from "./EditTodo";
import { getAllTodos } from "../services/TodoService";
import { useNavigate } from "react-router-dom";
import { useFetch } from "../customHooks/useFetch";
// import { useNavigation } from "react-router-dom";


export default function TodosList() {
    const navigate = useNavigate();

   //const [todos, setTodos] = useState([]);
    // const navigate = useNavigate();

    // const API_URL = 'https://jsonplaceholder.typicode.com/todos';

    //useEffect(()=>{

        // fetch('https://jsonplaceholder.typicode.com/todos')
        // .then((response) => response.json())
        // .then((data) => setTodos(data))
        // .catch(error => console.log(error))

        // getAllTodos()
        //     .then(response => setTodos(response.data))
        //     .catch(error => console.log('Error fetching data ' + error));
        
         // axios.get(`${API_URL}`)
        //     .then(response => setTodos(response.data))
        //     .catch(error => console.log('Error fetching data ' + error));

        // const response = await fetch(`${API_URL}`, {
        //     method: 'GET'
        // })
        // console.log(await response.json())
   // }, []);

    const [todos] = useFetch('https://jsonplaceholder.typicode.com/todos');

    function handleEdit(id) {
        //console.log("edit button clicked");
        navigate(`/edit/${id}`)
        
    }

    return (
        <div className="card">
            <div className="card-header bg-secondary">
                <h3 style={{textAlign: "center", color: "wheat"}}>Todos List</h3>
            </div>
            <div className="card-body">
                <table className="table table-striped">
                    <thead>
                        <tr>
                            <th>UserId</th>
                            <th>Id</th>
                            <th>Title</th>
                            <th>Completed</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    
                    <tbody>
                       {
                        todos.map(todo => (
                            <tr key={todo.id}>
                                <td>{todo.userId}</td>
                                <td>{todo.id}</td>
                                <td>{todo.title}</td>
                                <td>{todo.completed + ''}</td>
                                <td>
                                    <button className="btn btn-outline-warning" onClick={() => handleEdit(todo.id)}>Edit</button>
                                   
                                </td>
                            </tr>
                        ))
                       }
                    </tbody>
                </table>
            </div>
        </div>
    );
}
