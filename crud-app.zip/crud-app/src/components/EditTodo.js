// import axios from "axios";
import { useEffect, useState } from "react"
import { getTodo } from "../services/TodoService";
import { useParams } from "react-router-dom";
// import { useNavigation } from "react-router-dom";


export default function Edittodo() {
    // const navigation = useNavigation();

    let {todo_id} = useParams();
    
    const [todo, setTodo] = useState({
        userId: 0,
        id: 0,
        title: '',
        completed: false
    });

    

   // const API_URL = 'https://jsonplaceholder.typicode.com/todos';

    useEffect(() => {
        console.log(todo_id);
       getTodo(todo_id)
       .then(res => 
        {
            console.log(res.data);
            setTodo(res.data)
        })
       .catch(err => console.log(err))
    },[]);

    return (
        <div></div>
    )
}