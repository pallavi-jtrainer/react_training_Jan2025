// import logo from './logo.svg';
import './App.css';
import { BrowserRouter as Router, Routes, Route, Link } from 'react-router-dom';
import TodosList from './components/TodosList';
import Edittodo from './components/EditTodo';
import AddTodo from './components/AddTodo';

function App() {
  return (
    <Router>
      <div className="App">
        <nav className="navbar bg-dark navbar-expand-lg text-white" data-bs-theme="dark">
          <ul className="navbar-nav">
            <li className='nav-item space'>
              <Link to={'/'} className='nav-link'>Todo List</Link>
            </li>
            {/* <li className='nav-item space'>
              <Link to={'/edit'} className='nav-link'>Edit Todo</Link>
            </li> */}
            <li className='nav-item space'>
              <Link to={'/add'} className='nav-link'>Add Todo</Link>
            </li>
          </ul>
        </nav>
        <Routes>
            <Route path='/' exact Component={TodosList}></Route>
            <Route path="/edit/:id" Component={Edittodo}></Route>
            <Route path='/add' Component={AddTodo}></Route>
        </Routes>
      </div>
    </Router>
    // <div className="container">
    //   {/* <TodosList /> */}
    //   <Edittodo id="23"/>
    // </div>
  );
}

export default App;
