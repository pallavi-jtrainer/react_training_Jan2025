import { useEffect, useState } from "react";

export const useFetch = (url) => {
    const [data, setData] = useState([]);

    useEffect(() => {
        fetch(url)
        .then(res => res.json())
        .then(info => setData(info))
        .catch(error => console.log(error))
    });

    return [data];
}