import { useState } from "react";
import './Styles.css';

export default function Register() {
    const [firstName, setFirstName] = useState(""); 
    const [lastName, setLastName] = useState(""); 
    const [email, setEmail] = useState(""); 
    const [password, setPassword] = useState("");

    const [errors, setErrors] = useState({
        firstName: '',
        lastName: '',
        email: '',
        password: ''
    }); 
      
    const clearForm = () => { 
        setFirstName(""); 
        setLastName(""); 
        setEmail(""); 
        setPassword(""); 
    };

    const validateForm = () => {
        let valid = true;
        const regex = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/i;
        const temp = {...errors};
        if(!firstName.trim()) {
            temp.firstName = 'First Name is required';
            valid = false;
        } else {
            temp.firstName = '';
        }

        if(!lastName.trim()) {
            temp.lastName = 'Last Name is required';
            valid = false;
        } else {
            temp.lastName = '';
        }

        if(!email.trim()) {
            temp.email = 'Email is required';
            valid = false;
        } else if(!regex.test(email)) {
            temp.email = 'Email is invalid';
            valid = false;
        } else {
            temp.email = '';
        }

        if(!password.trim()) {
            temp.password = "Password is Required";
            valid = false;
        } else if (password.length < 8) {
            temp.password = 'Password should have minimum of 8 characters';
            valid = false;
        } else {
            temp.password = '';
        }

        setErrors(temp);
        return valid;
    }


    const saveUser = (e) => {
        e.preventDefault();

        console.log(validateForm());

        if(validateForm()) {
            const user = {firstName, lastName, email, password};
            console.log(user);
        }
    }

    return(
        <div className="container registration">
                <div className="card">
                    <div className="card-header bg-dark text-white">
                        <h2>Registration Form</h2>
                    </div>
                    <div className="card-body">
                        <form>
                            <div className="form-group">
                                <label>First Name: </label>
                                <input name="firstName" placeholder="Enter First Name"
                                   type="text" 
                                   className={`form-control ${errors.firstName ? 'is-invalid': ''}`}
                                   value={firstName} 
                                   onChange={(e) => setFirstName(e.target.value)}/>
                                {errors.firstName && <div className="invalid-feedback">{errors.firstName}</div>}
                            </div>
                            <div className="form-group">
                                <label>Last Name: </label>
                                <input name="lastName" placeholder="Enter Last Name"
                                   type="text" 
                                   className={`form-control ${errors.lastName ? 'is-invalid': ''}`}
                                   value={lastName} 
                                   onChange={(e) => setLastName(e.target.value)}/>
                                {errors.lastName && <div className="invalid-feedback">{errors.lastName}</div>}
                            </div>
                            <div className="form-group">
                                <label>Email: </label>
                                <input name="email" placeholder="Enter Email"
                                   type="email" 
                                   className={`form-control ${errors.email ? 'is-invalid': ''}`}
                                   value={email} 
                                   onChange={(e) => setEmail(e.target.value)}/>
                                {errors.email && <div className="invalid-feedback">{errors.email}</div>}
                            </div>
                            <div className="form-group"> 
                                <label>Password <sup>*</sup>: </label> 
                                <input 
                                    value={password} 
                                    type="password"
                                    className={`form-control ${errors.password ? 'is-invalid': ''}`}
                                    onChange={(e) => setPassword(e.target.value)} 
                                    placeholder="Password" 
                                /> 
                                {errors.password && <div className="invalid-feedback">{errors.password}</div>}
                            </div>
                        </form>
                        <div>
                            <button className="btn btn-success btnClass" onClick={(e) => saveUser(e)}>Save User Details</button>
                            <button className="btn btn-warning btnClass" style= {{'marginLeft': '3%'}} onClick={clearForm}>Reset Form</button>
                        </div>
                     </div>

                </div>
                
            </div>
    );
}